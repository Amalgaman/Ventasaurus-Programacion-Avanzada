package Interfaces;

public interface ManipulacionDB {
	
	
}
