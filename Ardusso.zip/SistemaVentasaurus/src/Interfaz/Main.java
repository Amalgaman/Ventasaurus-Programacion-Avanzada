package Interfaz;

import Jframes.VentanaError;

public class Main {

	public static void main(String[] args) {
		//VentanaError.run("adaaaaaaaaaaa adasda          dadada");
		MenuPrincipal.principal();
		
	}

}